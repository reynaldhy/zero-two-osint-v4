firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const db = firebase.firestore();

let scanCount = 0;
const SCAN_LIMIT = 5;

auth.onAuthStateChanged(user => {
  if(user){
    document.getElementById("auth").style.display = "none";
    document.getElementById("dashboard").style.display = "block";
    loadStats();
  } else {
    document.getElementById("auth").style.display = "block";
    document.getElementById("dashboard").style.display = "none";
  }
});

function register(){
  auth.createUserWithEmailAndPassword(
    document.getElementById("email").value,
    document.getElementById("password").value
  ).catch(alert);
}

function login(){
  auth.signInWithEmailAndPassword(
    document.getElementById("email").value,
    document.getElementById("password").value
  ).catch(alert);
}

function logout(){
  auth.signOut();
}

// SMART SCAN
async function smartScan(){
  if(scanCount >= SCAN_LIMIT){
    alert("Rate limit tercapai! Tunggu session baru.");
    return;
  }
  scanCount++;

  let t = document.getElementById("target").value;
  if(!t){ alert("Masukkan target!"); return; }

  let type = "Unknown";
  if(t.includes("@")) type="Email";
  else if(!isNaN(t.replace(/\./g,''))) type="IP";
  else if(t.includes(".")) type="Domain";
  else type="Username";

  let result = "Tipe Target: " + type + "<br>";

  if(type=="IP"){
    let res = await fetch(`https://ipapi.co/${t}/json/`);
    let data = await res.json();
    result += `Negara: ${data.country_name}<br>`;
    result += `Kota: ${data.city}<br>`;
    showMap(data.latitude, data.longitude);
  }

  // Risk Score
  let risk = 0;
  if(type=="Email" && t.includes("gmail")) risk += 20;
  if(type=="Email") risk += Math.floor(Math.random()*30);
  if(type=="IP") risk += Math.floor(Math.random()*20);
  result += `Risk Score: ${risk}/100<br>`;

  result += `<b>AI Summary:</b> Target ${t} kemungkinan ${type}, risiko ${risk}.
`;

  document.getElementById("result").innerHTML = result;

  db.collection("scans").add({
    target: t,
    type: type,
    risk: risk,
    time: new Date(),
    uid: auth.currentUser.uid
  });

  loadStats();
}

// Map
function showMap(lat,lon){
  var map = L.map('map').setView([lat, lon], 10);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{
  }).addTo(map);
  L.marker([lat, lon]).addTo(map);
}

// Load Stats
function loadStats(){
  db.collection("scans").where("uid","==",auth.currentUser.uid).get()
    .then(snapshot => {
      let html = `Total Scan: ${snapshot.size}<br>`;
      snapshot.forEach(doc => {
        html += `- ${doc.data().target} | Risk: ${doc.data().risk}<br>`;
      });
      document.getElementById("stats").innerHTML = html;
    });
}

// PHONE LOOKUP
async function phoneLookup(){
  let num = document.getElementById("phone").value;
  if(!num){ alert("Masukkan nomor HP"); return; }

  const apiKey = "MASUKKAN_API_KEY_MU"; // API Key dari Numverify
  const url = `https://apilayer.net/api/validate?access_key=${apiKey}&number=${num}`;

  try{
    let res = await fetch(url);
    let data = await res.json();

    let output = `Nomor: ${num}<br>`;
    output += `Valid: ${data.valid}<br>`;
    output += `Negara: ${data.country_name}<br>`;
    output += `Lokasi: ${data.location}<br>`;
    output += `Operator: ${data.carrier}<br>`;
    output += `Line type: ${data.line_type}<br>`;

    document.getElementById("phone-result").innerHTML = output;

    db.collection("phone_scans").add({
      number: num,
      country: data.country_name,
      location: data.location,
      carrier: data.carrier,
      line_type: data.line_type,
      time: new Date(),
      uid: auth.currentUser.uid
    });

  }catch(err){
    alert("Error: "+err);
  }
}